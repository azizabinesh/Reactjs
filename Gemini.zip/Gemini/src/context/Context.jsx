import React, { createContext, useState } from "react";
import runChat from "../config/Aziz";

export const Context = createContext();

const ContextProvider = (props) => {
  const [input, setInput] = useState("");
  const [recentPrompt, setRecentPrompt] = useState("");
  const [prePrompt, setPrePrompt] = useState([]);
  const [showResult, setShowResult] = useState(false);
  const [loading, setLoading] = useState(false);
  const [resultData, setResultData] = useState("");

  const delayPara = (index, nextWord) => {
    setTimeout(function name() {
      setResultData((prev) => prev + nextWord);
    }, 75 * index);
  };

  const onSent = async (prompt) => {
    setLoading(true);
    setResultData("");
    setShowResult(true);
    setRecentPrompt(input);
    setPrePrompt(prev=>[...prev,input])
    const response = await runChat(input);
    let responsArray = response.split("**");
    let newResponse = ""; // Initialize as empty string
    for (let i = 0; i < responsArray.length; i++) {
      if (i === 0 || i % 2 !== 0) {
        // Fix array index condition
        newResponse += responsArray[i];
      } else {
        newResponse += "<b>" + responsArray[i] + "</b>";
      }
    }
    let newresponse2 = newResponse.split("*").join("</br>");
    let newresponseArray = newresponse2.split(" ");
    for (let i = 0; i < newresponseArray.length; i++) {
      const nextWord = newresponseArray[i];
      delayPara(i, nextWord + " ");
    }
    setLoading(false);
    setInput("");
  };

  const contextValue = {
    input,
    setInput,
    recentPrompt,
    setRecentPrompt,
    prePrompt,
    setPrePrompt,
    showResult,
    setShowResult,
    loading,
    setLoading,
    resultData,
    setResultData,
    onSent,
  };

  return (
    <Context.Provider value={contextValue}>{props.children}</Context.Provider>
  );
};

export default ContextProvider;
